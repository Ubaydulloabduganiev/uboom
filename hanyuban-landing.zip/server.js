import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

/**
 * HANYUBAN lead backend.
 * Keeps Telegram bot token private and forwards lead form submissions to a Telegram group.
 */
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

function escapeHtml(text = '') {
  return String(text)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

app.post('/api/lead', async (req, res) => {
  try {
    const { name, phone, course, age, message, source } = req.body || {};

    if (!name || !phone) {
      return res.status(400).json({ ok: false, error: 'Name and phone are required.' });
    }

    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;

    if (!token || !chatId) {
      return res.status(503).json({
        ok: false,
        error: 'Telegram forwarding is not configured yet.'
      });
    }

    const text = `🔥 <b>Yangi lead: HANYUBAN</b>\n\n` +
      `👤 Ism: <b>${escapeHtml(name)}</b>\n` +
      `📞 Telefon: <b>${escapeHtml(phone)}</b>\n` +
      `🎯 Kurs: ${escapeHtml(course || 'Tanlanmagan')}\n` +
      `🎂 Yosh: ${escapeHtml(age || 'Kiritilmagan')}\n` +
      `💬 Izoh: ${escapeHtml(message || 'Yo‘q')}\n` +
      `🌐 Manba: ${escapeHtml(source || 'Website')}`;

    const tgResponse = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' })
    });

    const data = await tgResponse.json();
    if (!data.ok) {
      return res.status(502).json({ ok: false, error: data.description || 'Telegram error' });
    }

    return res.json({ ok: true });
  } catch (error) {
    console.error('Lead error:', error);
    return res.status(500).json({ ok: false, error: 'Server error.' });
  }
});

app.listen(PORT, () => {
  console.log(`HANYUBAN landing running on http://localhost:${PORT}`);
});
