# HANYUBAN Landing Page

Premium multilingual landing page for HANYUBAN Chinese language center.

## Fast static preview
Open `public/index.html` in your browser.

## Full launch with Telegram lead form
1. Install Node.js.
2. Open terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your Telegram bot token and group chat ID into `.env`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Deployment
Can be deployed to Render, Railway, VPS, Oracle Always Free, or any Node.js hosting.

Important: do not put Telegram bot token into frontend JavaScript. Use `server.js`.
