const translations = {
  uz: {
    navCourses:'Kurslar', navPath:'Yo‘l xaritasi', navWhy:'Afzalliklar', navContact:'Aloqa',
    heroTitle:'Xitoy tilini noldan HSK darajasigacha o‘rganing',
    heroLead:'HANYUBAN bolalar, o‘quvchilar, talabalar va kattalar uchun xitoy tili kurslarini taklif qiladi: noldan boshlash, HSK tayyorgarlik, speaking va amaliy natija.',
    trialBtn:'Sinov darsiga yozilish', telegramBtn:'Telegramga yozish', statWeek:'haftasiga dars', statMin:'daqiqa', statHsk:'tayyorgarlik',
    cardTitle:'1 ta sinov darsi', cardText:'Darajangizni aniqlaymiz, mos guruhni tavsiya qilamiz va o‘qish rejangizni tushuntiramiz.',
    coursesKicker:'Kurslar', coursesTitle:'Har bir maqsad uchun xitoy tili kurslari',
    c1Title:'Noldan xitoy tili', c1Text:'Pinyin, talaffuz, ierogliflar va eng kerakli so‘zlashuv bazasi.', c2Title:'HSK tayyorgarlik', c2Text:'HSK 1 dan HSK 5 gacha bosqichma-bosqich imtihon tayyorgarligi.', c3Title:'Speaking kursi', c3Text:'Xitoy tilida gapirish, savol-javob, real vaziyatlarda muloqot.', c4Title:'Bolalar guruhlari', c4Text:'Yoshga mos, qiziqarli va tartibli xitoy tili darslari.', c5Title:'Individual darslar', c5Text:'Shaxsiy maqsad, tezroq progress va moslashtirilgan dastur.', c6Title:'Online darslar', c6Text:'Tez orada masofadan xitoy tili o‘rganish imkoniyati qo‘shiladi.',
    pathKicker:'Yo‘l xaritasi', pathTitle:'Noldan boshlaysiz. Reja bilan o‘sasiz.', pathText:'O‘quvchi shunchaki darsga kelmaydi. U qaysi bosqichda ekanini, keyingi maqsadini va HSK sari yo‘lini bilib boradi.', step1:'Sinov darsi va daraja aniqlash', step2:'Mos guruh yoki individual reja', step3:'Haftasiga 3 marta 60 daqiqalik dars', step4:'HSK, speaking va real natija',
    whyKicker:'Nega HANYUBAN?', whyTitle:'Xitoy tili modaga emas, kelajakka kerak', w1Title:'Tizimli dastur', w1Text:'Darslar pinyin, lug‘at, grammatika, listening, speaking va HSK ko‘nikmalarini birga rivojlantiradi.', w2Title:'Amaliy yondashuv', w2Text:'O‘quvchi faqat qoida yodlamaydi. Gapirish, tushunish va ishlatishni o‘rganadi.', w3Title:'Hamma uchun', w3Text:'Bolalar, maktab o‘quvchilari, talabalar va kattalar uchun mos guruhlar.', w4Title:'Natijaga yo‘naltirilgan', w4Text:'Maqsad oddiy: o‘quvchi xitoy tilini tushunsin, gapirsin va HSK bosqichlariga tayyor bo‘lsin.',
    quoteTitle:'Orzu o‘ylab emas, harakat bilan amalga oshadi.', contactKicker:'Ro‘yxatdan o‘tish', contactTitle:'Sinov darsiga yoziling', contactText:'Formani to‘ldiring. Menejer siz bilan bog‘lanib, narx, jadval va mos guruh haqida ma’lumot beradi.', nameLabel:'Ismingiz', phoneLabel:'Telefon raqamingiz', ageLabel:'Yosh', courseLabel:'Qiziqayotgan kurs', messageLabel:'Izoh', submitBtn:'Yuborish', floatBtn:'Sinov darsi', footerText:'Xitoy tili o‘quv markazi. Narx va jadval menejer tomonidan tasdiqlanadi.'
  },
  ru: {
    navCourses:'Курсы', navPath:'Путь обучения', navWhy:'Преимущества', navContact:'Контакты',
    heroTitle:'Изучайте китайский с нуля до уровня HSK', heroLead:'HANYUBAN предлагает курсы китайского языка для детей, школьников, студентов и взрослых: старт с нуля, подготовка к HSK, speaking и практический результат.', trialBtn:'Записаться на пробный урок', telegramBtn:'Написать в Telegram', statWeek:'занятия в неделю', statMin:'минут', statHsk:'подготовка', cardTitle:'1 пробный урок', cardText:'Мы определим уровень, подберём подходящую группу и объясним учебный план.', coursesKicker:'Курсы', coursesTitle:'Китайский язык под любую цель', c1Title:'Китайский с нуля', c1Text:'Pinyin, произношение, иероглифы и базовая разговорная лексика.', c2Title:'Подготовка к HSK', c2Text:'Поэтапная подготовка к HSK от 1 до 5 уровня.', c3Title:'Speaking курс', c3Text:'Разговорная практика, вопросы-ответы и реальные ситуации.', c4Title:'Детские группы', c4Text:'Интересные и системные занятия по возрасту.', c5Title:'Индивидуальные уроки', c5Text:'Личная цель, быстрый прогресс и адаптированная программа.', c6Title:'Онлайн уроки', c6Text:'Скоро добавится возможность изучать китайский онлайн.', pathKicker:'Путь обучения', pathTitle:'Начинаете с нуля. Растёте по системе.', pathText:'Ученик понимает свой уровень, следующую цель и путь к HSK.', step1:'Пробный урок и определение уровня', step2:'Подходящая группа или личный план', step3:'3 раза в неделю по 60 минут', step4:'HSK, speaking и реальный результат', whyKicker:'Почему HANYUBAN?', whyTitle:'Китайский нужен не для моды, а для будущего', w1Title:'Системная программа', w1Text:'Уроки развивают pinyin, словарь, грамматику, listening, speaking и HSK-навыки.', w2Title:'Практический подход', w2Text:'Ученик не просто учит правила, а учится понимать и говорить.', w3Title:'Для всех', w3Text:'Группы для детей, школьников, студентов и взрослых.', w4Title:'Фокус на результате', w4Text:'Цель простая: понимать китайский, говорить и готовиться к HSK.', quoteTitle:'Мечта исполняется не мыслями, а действиями.', contactKicker:'Запись', contactTitle:'Запишитесь на пробный урок', contactText:'Заполните форму. Менеджер свяжется с вами и объяснит цену, расписание и подходящую группу.', nameLabel:'Ваше имя', phoneLabel:'Телефон', ageLabel:'Возраст', courseLabel:'Интересующий курс', messageLabel:'Комментарий', submitBtn:'Отправить', floatBtn:'Пробный урок', footerText:'Центр китайского языка. Цены и расписание подтверждает менеджер.'
  },
  zh: {
    navCourses:'课程', navPath:'学习路径', navWhy:'优势', navContact:'联系', heroTitle:'从零基础学到 HSK 水平', heroLead:'HANYUBAN 为儿童、学生和成人提供中文课程：零基础、HSK 备考、口语训练和实际进步。', trialBtn:'预约试听课', telegramBtn:'Telegram 联系', statWeek:'每周课程', statMin:'分钟', statHsk:'备考', cardTitle:'一次试听课', cardText:'我们会测试水平，推荐合适班级，并说明学习计划。', coursesKicker:'课程', coursesTitle:'适合不同目标的中文课程', c1Title:'零基础中文', c1Text:'拼音、发音、汉字和基础口语。', c2Title:'HSK 备考', c2Text:'从 HSK 1 到 HSK 5 的系统准备。', c3Title:'口语课程', c3Text:'中文表达、问答练习和真实情景交流。', c4Title:'儿童班', c4Text:'适合年龄的有趣系统课程。', c5Title:'一对一课程', c5Text:'个人目标、更快进步和定制计划。', c6Title:'线上课程', c6Text:'线上学习中文即将推出。', pathKicker:'学习路径', pathTitle:'从零开始，按计划进步。', pathText:'学生会清楚自己的阶段、下一步目标和通往 HSK 的路径。', step1:'试听课和水平测试', step2:'合适班级或个人计划', step3:'每周3次，每次60分钟', step4:'HSK、口语和真实结果', whyKicker:'为什么选择 HANYUBAN？', whyTitle:'中文不是潮流，是未来。', w1Title:'系统课程', w1Text:'课程同时提升拼音、词汇、语法、听力、口语和 HSK 能力。', w2Title:'实用方法', w2Text:'学生不只是背规则，而是学会理解和表达。', w3Title:'适合所有人', w3Text:'儿童、学生和成人都有合适的班级。', w4Title:'结果导向', w4Text:'目标明确：理解中文、开口说话、准备 HSK。', quoteTitle:'梦想不是想出来的，是干出来的。', contactKicker:'报名', contactTitle:'预约试听课', contactText:'填写表格，老师会联系您说明价格、时间和合适班级。', nameLabel:'姓名', phoneLabel:'电话', ageLabel:'年龄', courseLabel:'感兴趣的课程', messageLabel:'备注', submitBtn:'提交', floatBtn:'试听课', footerText:'中文学习中心。价格和时间由老师确认。'
  }
};

const langButtons = document.querySelectorAll('[data-lang]');
const i18nNodes = document.querySelectorAll('[data-i18n]');

function setLang(lang) {
  const dict = translations[lang] || translations.uz;
  document.documentElement.lang = lang;
  i18nNodes.forEach(node => {
    const key = node.dataset.i18n;
    if (dict[key]) node.textContent = dict[key];
  });
  langButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.lang === lang));
  localStorage.setItem('hanyuban_lang', lang);
}

langButtons.forEach(btn => btn.addEventListener('click', () => setLang(btn.dataset.lang)));
setLang(localStorage.getItem('hanyuban_lang') || 'uz');

const form = document.getElementById('lead-form');
const statusEl = document.getElementById('form-status');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  data.source = 'HANYUBAN Landing Page';
  statusEl.textContent = 'Yuborilmoqda...';

  try {
    const response = await fetch('/api/lead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || 'Form error');
    statusEl.textContent = '✅ Qabul qilindi. Menejer tez orada bog‘lanadi.';
    form.reset();
  } catch (error) {
    const text = `Assalomu alaykum, HANYUBAN sinov darsiga yozilmoqchiman.%0AIsm: ${encodeURIComponent(data.name || '')}%0ATelefon: ${encodeURIComponent(data.phone || '')}%0AKurs: ${encodeURIComponent(data.course || '')}`;
    statusEl.innerHTML = `Form backend hali sozlanmagan. <a href="https://t.me/Hanyubanbot?start=website" target="_blank" rel="noopener">Telegram botga yozing</a>.`;
  }
});
